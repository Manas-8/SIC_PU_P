import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# ========================
# Sales Data Summary Class
# ========================
class SalesDataSummary:
    """Provides statistical summaries and grouped data for sales analysis."""

    def __init__(self, df):
        # Clean column names by stripping whitespace
        self.df = df
        self.df.columns = self.df.columns.str.strip()  

        # Convert 'Order Date' to datetime and extract day names if the column exists
        if 'Order Date' in self.df.columns:
            self.df['Order Date'] = pd.to_datetime(self.df['Order Date'])
            self.df['Day'] = self.df['Order Date'].dt.day_name()

    def summary_statistics(self):
        # Calculate basic statistics for numeric columns
        numeric_cols = ['Sales', 'Profit', 'Quantity', 'Returns']
        summary = pd.DataFrame({
            'Mean': self.df[numeric_cols].mean(),
            'Median': self.df[numeric_cols].median(),
            'Min': self.df[numeric_cols].min(),
            'Max': self.df[numeric_cols].max(),
            'Std Dev': self.df[numeric_cols].std()
        })
        return summary.round(2)  # Round to 2 decimal places for readability

    def statewise_summary(self):
        # Group by state and calculate aggregated metrics
        return self.df.groupby('State').agg({
            'Sales': ['sum', 'mean'],  # Both total and average sales per state
            'Profit': ['sum', 'mean'],
            'Quantity': 'sum',
            'Returns': 'sum'
        }).round(2).sort_values(('Sales', 'sum'), ascending=False)  # Sort by total sales

    def categorywise_summary(self):
        # Similar to statewise but grouped by product category
        return self.df.groupby('Category').agg({
            'Sales': ['sum', 'mean'],
            'Profit': ['sum', 'mean'],
            'Quantity': 'sum',
            'Returns': 'sum'
        }).round(2).sort_values(('Sales', 'sum'), ascending=False)

    def daywise_summary(self):
        # Ensure 'Day' column exists (might not if Order Date wasn't in original data)
        if 'Day' not in self.df.columns:
            self.df['Day'] = self.df['Order Date'].dt.day_name()

        # Define order of days for proper sorting (Monday-Sunday)
        day_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        result = self.df.groupby('Day').agg({
            'Sales': ['sum', 'mean'],
            'Profit': ['sum', 'mean'],
            'Returns': 'sum'
        }).round(2).reindex(day_order)  # Reindex to enforce day order

        return result

    def payment_mode_summary(self):
        # Analyze sales by payment method (credit card, cash, etc.)
        return self.df.groupby('Payment Mode').agg({
            'Sales': ['sum', 'mean'],
            'Returns': 'sum'
        }).round(2).sort_values(('Sales', 'sum'), ascending=False)

    def top_products(self, n=10):
        # Get top n products by total sales
        return self.df.groupby('Product Name')['Sales'].sum().sort_values(ascending=False).head(n)


# ========================
# Visualisation Class
# ========================
class Visualisation:
    """Handles various plotting functions for sales data."""
    
    def __init__(self, df):
        self.df = df

    @staticmethod
    def plot_statewise_sales_profit(df):
        # Group by state and calculate total sales and profit
        state_sales = df.groupby('State').agg({'Sales': 'sum', 'Profit': 'sum'}).sort_values(by='Sales', ascending=False)
        
        # Create a bar plot with two bars per state (sales and profit)
        ax = state_sales.plot(kind='bar', figsize=(14, 6), color=['skyblue', 'salmon'])
        plt.title("State-wise Total Sales and Profit")
        plt.xlabel("State")
        plt.ylabel("Amount in USD")
        plt.xticks(rotation=45, ha='right')  # Rotate x-axis labels for readability
        plt.grid(axis='y', linestyle='--', alpha=0.7)  # Add light grid lines
        plt.tight_layout()  # Adjust layout to prevent label cutoff
        plt.show()

    @staticmethod
    def plot_daywise_sales(df):
        # Ensure 'Day' column exists
        if 'Day' not in df.columns:
            df['Day'] = df['Order Date'].dt.day_name()
        
        # Define day order and group data
        day_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        daywise_sales = df.groupby('Day')['Sales'].sum().reindex(day_order)
        
        # Create bar chart
        ax = daywise_sales.plot(kind='bar', figsize=(10, 5), color='lightgreen')
        plt.title("Day-wise Sales Distribution")
        plt.xlabel("Day of Week")
        plt.ylabel("Total Sales")
        plt.xticks(rotation=45)
        plt.grid(axis='y', linestyle='--', alpha=0.7)
        plt.tight_layout()
        plt.show()

    @staticmethod
    def plot_payment_mode_pie(df):
        # Calculate total sales by payment method
        payment_sales = df.groupby('Payment Mode')['Sales'].sum()
        
        # Create a color palette for the pie chart
        colors = plt.cm.Paired(np.linspace(0, 1, len(payment_sales)))
        
        plt.figure(figsize=(8, 8))
        plt.pie(payment_sales, 
                labels=payment_sales.index, 
                autopct='%1.1f%%',  # Show percentages
                colors=colors, 
                startangle=140)  # Rotate pie for better visibility
        plt.title("Sales Distribution by Payment Mode")
        plt.tight_layout()
        plt.show()

    @staticmethod
    def plot_categorywise_sales(df):
        # Group sales by category and sort
        category_sales = df.groupby('Category')['Sales'].sum().sort_values()
        
        plt.figure(figsize=(12, 6))
        # Create horizontal bar chart
        bars = plt.barh(category_sales.index, category_sales.values, color='mediumslateblue')
        plt.xlabel("Total Sales")
        plt.title("Category-wise Sales Analysis")
        plt.grid(axis='x', linestyle='--', alpha=0.7)
        
        # Add value labels to each bar
        for bar in bars:
            width = bar.get_width()
            plt.text(width + 10, bar.get_y() + bar.get_height()/2, 
                    f"${width:,.0f}",  # Format as currency with commas
                    va='center')  # Vertical alignment
        plt.tight_layout()
        plt.show()

    @staticmethod
    def plot_monthly_trends(df):
        # Convert to datetime and extract month
        df['Order Date'] = pd.to_datetime(df['Order Date'])
        df['Month'] = df['Order Date'].dt.to_period('M')
        
        # Group by month and calculate totals
        monthly = df.groupby('Month')[['Sales', 'Profit']].sum()
        monthly.index = monthly.index.to_timestamp()  # Convert period back to datetime for plotting
        
        plt.figure(figsize=(14, 6))
        # Plot sales and profit as separate lines
        plt.plot(monthly.index, monthly['Sales'], marker='o', label='Sales', color='royalblue')
        plt.plot(monthly.index, monthly['Profit'], marker='o', label='Profit', color='darkorange')
        plt.title("Monthly Sales and Profit Trend")
        plt.xlabel("Month")
        plt.ylabel("Amount in USD")
        plt.grid(True, linestyle='--', alpha=0.6)
        plt.xticks(rotation=45)
        plt.legend()
        plt.tight_layout()
        plt.show()


# ========================
# Main Script
# ========================
if __name__ == "__main__":
    # Load dataset and clean column names
    file = pd.read_excel("C:/Users/Admin/Downloads/Amazon US dataset.xlsx")
    file.columns = file.columns.str.strip()

    # Create analysis objects
    vis = Visualisation(file)
    summary = SalesDataSummary(file)

    # Menu system for user interaction
    def display_menu():
        print("\n=== Amazon US Sales Analysis Menu ===")
        print("1. Plot: State-wise Sales and Profit")
        print("2. Plot: Day-wise Sales")
        print("3. Plot: Payment Mode Distribution (Pie Chart)")
        print("4. Plot: Category-wise Sales (Horizontal Bar)")
        print("5. Plot: Monthly Sales and Profit Trends")
        print("6. Table: Category-wise Summary")
        print("7. Table: State-wise Summary")
        print("8. Table: Summary Statistics")
        print("9. Table: Day-wise Summary")
        print("10. Table: Payment Mode Summary")
        print("11. Table: Top 10 Products by Sales")
        print("0. Exit")

    while True:
        display_menu()
        choice = input("Enter your choice (0-11): ")

        if choice == '1':
            vis.plot_statewise_sales_profit(file)
        elif choice == '2':
            vis.plot_daywise_sales(file)
        elif choice == '3':
            vis.plot_payment_mode_pie(file)
        elif choice == '4':
            vis.plot_categorywise_sales(file)
        elif choice == '5':
            vis.plot_monthly_trends(file)
        elif choice == '6':
            print("\nCategory-wise Summary:\n", summary.categorywise_summary())
        elif choice == '7':
            print("\nState-wise Summary:\n", summary.statewise_summary())
        elif choice == '8':
            print("\nSummary Statistics:\n", summary.summary_statistics())
        elif choice == '9':
            print("\nDay-wise Summary:\n", summary.daywise_summary())
        elif choice == '10':
            print("\nPayment Mode Summary:\n", summary.payment_mode_summary())
        elif choice == '11':
            print("\nTop 10 Products by Sales:\n", summary.top_products())
        elif choice == '0':
            print("Exiting the program. Goodbye!")
            break
        else:
            print("Invalid input. Please choose a number between 0 and 11.")