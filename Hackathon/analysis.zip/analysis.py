import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


# Sales Data Summary Class

class SalesDataSummary:
    """Provides statistical summaries and grouped data for sales analysis."""

    def __init__(self, df):
        self.df = df
        self.df.columns = self.df.columns.str.strip()  # Clean column names

        if 'Order Date' in self.df.columns:
            self.df['Order Date'] = pd.to_datetime(self.df['Order Date'])
            self.df['Day'] = self.df['Order Date'].dt.day_name()

    def summary_statistics(self):
        numeric_cols = ['Sales', 'Profit', 'Quantity', 'Returns']
        summary = pd.DataFrame({
            'Mean': self.df[numeric_cols].mean(),
            'Median': self.df[numeric_cols].median(),
            'Min': self.df[numeric_cols].min(),
            'Max': self.df[numeric_cols].max(),
            'Std Dev': self.df[numeric_cols].std()
        })
        return summary.round(2)

    def statewise_summary(self):
        return self.df.groupby('State').agg({
            'Sales': ['sum', 'mean'],
            'Profit': ['sum', 'mean'],
            'Quantity': 'sum',
            'Returns': 'sum'
        }).round(2).sort_values(('Sales', 'sum'), ascending=False)

    def categorywise_summary(self):
        return self.df.groupby('Category').agg({
            'Sales': ['sum', 'mean'],
            'Profit': ['sum', 'mean'],
            'Quantity': 'sum',
            'Returns': 'sum'
        }).round(2).sort_values(('Sales', 'sum'), ascending=False)

    def daywise_summary(self):
        if 'Day' not in self.df.columns:
            self.df['Day'] = self.df['Order Date'].dt.day_name()

        day_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        result = self.df.groupby('Day').agg({
            'Sales': ['sum', 'mean'],
            'Profit': ['sum', 'mean'],
            'Returns': 'sum'
        }).round(2).reindex(day_order)

        return result

    def payment_mode_summary(self):
        return self.df.groupby('Payment Mode').agg({
            'Sales': ['sum', 'mean'],
            'Returns': 'sum'
        }).round(2).sort_values(('Sales', 'sum'), ascending=False)

    def top_products(self, n=10):
        return self.df.groupby('Product Name')['Sales'].sum().sort_values(ascending=False).head(n)


# Visualisation Class

class Visualisation:
    """Handles various plotting functions for sales data."""
    
    def __init__(self, df):
        self.df = df

    @staticmethod
    def plot_statewise_sales_profit(df):
        state_sales = df.groupby('State').agg({'Sales': 'sum', 'Profit': 'sum'}).sort_values(by='Sales', ascending=False)
        ax = state_sales.plot(kind='bar', figsize=(14, 6), color=['skyblue', 'salmon'])
        plt.title("State-wise Total Sales and Profit")
        plt.xlabel("State")
        plt.ylabel("Amount in USD")
        plt.xticks(rotation=45, ha='right')
        plt.grid(axis='y', linestyle='--', alpha=0.7)
        plt.tight_layout()
        plt.show()

    @staticmethod
    def plot_daywise_sales(df):
        if 'Day' not in df.columns:
            df['Day'] = df['Order Date'].dt.day_name()
        day_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        daywise_sales = df.groupby('Day')['Sales'].sum().reindex(day_order)
        ax = daywise_sales.plot(kind='bar', figsize=(10, 5), color='lightgreen')
        plt.title("Day-wise Sales Distribution")
        plt.xlabel("Day of Week")
        plt.ylabel("Total Sales")
        plt.xticks(rotation=45)
        plt.grid(axis='y', linestyle='--', alpha=0.7)
        plt.tight_layout()
        plt.show()

    @staticmethod
    def plot_payment_mode_pie(df):
        payment_sales = df.groupby('Payment Mode')['Sales'].sum()
        colors = plt.cm.Paired(np.linspace(0, 1, len(payment_sales)))
        plt.figure(figsize=(8, 8))
        plt.pie(payment_sales, labels=payment_sales.index, autopct='%1.1f%%',
                colors=colors, startangle=140)
        plt.title("Sales Distribution by Payment Mode")
        plt.tight_layout()
        plt.show()

    @staticmethod
    def plot_categorywise_sales(df):
        category_sales = df.groupby('Category')['Sales'].sum().sort_values()
        plt.figure(figsize=(12, 6))
        bars = plt.barh(category_sales.index, category_sales.values, color='mediumslateblue')
        plt.xlabel("Total Sales")
        plt.title("Category-wise Sales Analysis")
        plt.grid(axis='x', linestyle='--', alpha=0.7)
        for bar in bars:
            width = bar.get_width()
            plt.text(width + 10, bar.get_y() + bar.get_height()/2, f"${width:,.0f}", va='center')
        plt.tight_layout()
        plt.show()

    @staticmethod
    def plot_monthly_trends(df):
        df['Order Date'] = pd.to_datetime(df['Order Date'])
        df['Month'] = df['Order Date'].dt.to_period('M')
        monthly = df.groupby('Month')[['Sales', 'Profit']].sum()
        monthly.index = monthly.index.to_timestamp()
        plt.figure(figsize=(14, 6))
        plt.plot(monthly.index, monthly['Sales'], marker='o', label='Sales', color='royalblue')
        plt.plot(monthly.index, monthly['Profit'], marker='o', label='Profit', color='darkorange')
        plt.title("Monthly Sales and Profit Trend")
        plt.xlabel("Month")
        plt.ylabel("Amount in USD")
        plt.grid(True, linestyle='--', alpha=0.6)
        plt.xticks(rotation=45)
        plt.legend()
        plt.tight_layout()
        plt.show()



# Main Script

# Load dataset
file = pd.read_excel("C:/Users/Admin/Downloads/Amazon US dataset.xlsx")
file.columns = file.columns.str.strip()

    # Object creation
vis = Visualisation(file)
summary = SalesDataSummary(file)

  

    # Visualization
vis.plot_statewise_sales_profit(file)
vis.plot_payment_mode_pie(file)
vis.plot_categorywise_sales(file)
vis.plot_daywise_sales(file)
vis.plot_monthly_trends(file)

    # Tabular Summaries
print(summary.categorywise_summary())
print(summary.statewise_summary())
print(summary.summary_statistics())
print(summary.daywise_summary())
print(summary.payment_mode_summary())
print(summary.top_products())
